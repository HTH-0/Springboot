INSERT IGNORE INTO tbl_a values(1,111);
INSERT IGNORE INTO tbl_a values(2,222);
INSERT IGNORE INTO tbl_a values(3,333);
